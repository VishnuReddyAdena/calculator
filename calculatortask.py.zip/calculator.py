from tkinter import *
window = Tk()
window.geometry("500x500")

entry = Entry(window, width=50, borderwidth=5)
entry.place(x=0, y=0)

def click(num):
    result = entry.get()
    entry.delete(0, END)
    entry.insert(0, str(result) + str(num))

b = Button(window, text="1", width=5, command=lambda: click(1))
b.place(x=10, y=60)
b = Button(window, text="2", width=5, command=lambda: click(2))
b.place(x=60, y=60)
b = Button(window, text="3", width=5, command=lambda: click(3))
b.place(x=110, y=60)
b = Button(window, text="4", width=5, command=lambda: click(4))
b.place(x=10, y=95)
b = Button(window, text="5", width=5, command=lambda: click(5))
b.place(x=60, y=95)
b = Button(window, text="6", width=5, command=lambda: click(6))
b.place(x=110, y=95)
b = Button(window, text="7", width=5, command=lambda: click(7))
b.place(x=10, y=130)
b = Button(window, text="8", width=5, command=lambda: click(8))
b.place(x=60, y=130)
b = Button(window, text="9", width=5, command=lambda: click(9))
b.place(x=110, y=130)
b = Button(window, text="0", width=5, command=lambda: click(0))
b.place(x=60, y=170)

def click_decimal():
    result = entry.get()
    if '.' not in result:
        entry.insert(END, '.')

b = Button(window, text=".", width=5, command=click_decimal)
b.place(x=110, y=170)

def mod():
    n1 = entry.get()
    global math
    math = "modulus"
    global i
    try:
        i = float(n1)
    except ValueError:
        i = 0
    entry.delete(0, END)
b = Button(window, text="%", width=5, command=mod)
b.place(x=10, y=170)

def mult():
    n1 = entry.get()
    global math
    math = "multiplication"
    global i
    try:
        i = float(n1)
    except ValueError:
        i = 0
    entry.delete(0, END)
b = Button(window, text="x", width=5, command=mult)
b.place(x=160, y=60)

def sub():
    n1 = entry.get()
    global math
    math = "subtraction"
    global i
    try:
        i = float(n1)
    except ValueError:
        i = 0
    entry.delete(0, END)
b = Button(window, text="-", width=5, command=sub)
b.place(x=160, y=95)

def add():
    n1 = entry.get()
    global math
    math = "addition"
    global i
    try:
        i = float(n1)
    except ValueError:
        i = 0
    entry.delete(0, END)
b = Button(window, text="+", width=5, command=add)
b.place(x=160, y=130)

def div():
    n1 = entry.get()
    global math
    math = "division"
    global i
    try:
        i = float(n1)
    except ValueError:
        i = 0
    entry.delete(0, END)
b = Button(window, text="/", width=5, command=div)
b.place(x=160, y=30)

def equal():
    n2 = entry.get()
    entry.delete(0, END)
    try:
        operand = float(n2)
        if math == "addition":
            entry.insert(0, i + operand)
        elif math == "subtraction":
            entry.insert(0, i - operand)
        elif math == "multiplication":
            entry.insert(0, i * operand)
        elif math == "modulus":
            entry.insert(0, i % operand)
        elif math == "division":
            if operand == 0:
                entry.insert(0, "Error")
            else:
                entry.insert(0, i / operand)
    except Exception:
        entry.insert(0, "Error")

b = Button(window, text="=", width=5, command=equal)
b.place(x=160, y=170)

def clear():
    entry.delete(0, END)

b = Button(window, text="AC", width=5, command=clear)
b.place(x=10, y=30)

def backspace():
    current_text = entry.get()
    new_text = current_text[:-1]
    entry.delete(0, END)
    entry.insert(0, new_text)

b = Button(window, text="<-", width=5, command=backspace)
b.place(x=60, y=30)

def plus_minus():
    current = entry.get()
    if current:
        if current.startswith('-'):
            entry.delete(0, END)
            entry.insert(0, current[1:])
        else:
            entry.delete(0, END)
            entry.insert(0, '-' + current)

b = Button(window, text="+/-", width=5, command=plus_minus)
b.place(x=110, y=30)

window.mainloop()
